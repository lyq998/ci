function y = dejong1(x1, x2)
    y = x1.^2 + x2.^2;
end